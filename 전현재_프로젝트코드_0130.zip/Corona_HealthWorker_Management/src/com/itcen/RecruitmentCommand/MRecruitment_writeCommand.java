package com.itcen.RecruitmentCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itcen.DAO.RecruitmentDAO;

public class MRecruitment_writeCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
	
			String bName = request.getParameter("bName");
			String bTitle = request.getParameter("title");
			String bContent = request.getParameter("bContent");
			
			RecruitmentDAO dao = new RecruitmentDAO();
			dao.write(bName, bTitle, bContent);
	
	}

}
