package com.itcen.RecruitmentCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itcen.DAO.RecruitmentDAO;
import com.itcen.DTO.RecruitmentDTO;

public class Putoff_replyview implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
	
		String bId = request.getParameter("rId");
		RecruitmentDAO dao = new RecruitmentDAO();
		RecruitmentDTO dto = dao.reply_view(bId);
		
		request.setAttribute("reply_view", dto);
	}

}
