package com.itcen.RecruitmentCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itcen.DAO.RecruitmentDAO;
import com.itcen.DTO.RecruitmentDTO;

public class WRecruitment_viewCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		RecruitmentDAO recruitmentDao = new RecruitmentDAO();
		int pageSize = 10;
		String rRecruitment_location_city_opt = request.getParameter("rRecruitment_location_city_opt");
		String rRecruitment_location_district_opt = request.getParameter("rRecruitment_location_district_opt");
		String rRecruitment_necessary_job_opt = request.getParameter("rRecruitment_necessary_job_opt");
		String pageNum = request.getParameter("pageNum");
		if(pageNum == null) {
			pageNum = "1";
		}
		
		int currentPage = Integer.parseInt(pageNum);
		int startRow = (currentPage - 1) * pageSize + 1;
		int endRow = currentPage * pageSize;
		
		int count = 0;
		count = recruitmentDao.getCount();
		ArrayList<RecruitmentDTO> recruitmentDto = null;
		if (count > 0) {
			recruitmentDto = recruitmentDao.list(startRow, endRow, rRecruitment_location_city_opt, rRecruitment_location_district_opt, rRecruitment_necessary_job_opt);
		}
		request.setAttribute("list", recruitmentDto);
	}
		
	
	
}
