package com.itcen.RecruitmentCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itcen.DAO.RecruitmentDAO;

public class MRecruitment_modifyCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		String bId = request.getParameter("rId");
		String bName = request.getParameter("bName");
		String bTitle = request.getParameter("title");
		String bContent = request.getParameter("bContent");
		
		RecruitmentDAO dao = new RecruitmentDAO();
		dao.modify(bId, bName, bTitle, bContent);
	}
}
