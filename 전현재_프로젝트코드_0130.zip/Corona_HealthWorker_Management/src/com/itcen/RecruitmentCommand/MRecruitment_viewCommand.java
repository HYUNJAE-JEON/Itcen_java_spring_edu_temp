package com.itcen.RecruitmentCommand;

public class MRecruitment_viewCommand {

}
