package com.itcen.RecruitmentCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itcen.DAO.RecruitmentDAO;

public class MRecruitment_deleteCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String bId = request.getParameter("rId");
		RecruitmentDAO dao = new RecruitmentDAO();
		dao.delete(bId);
	}
	
}
