package com.itcen.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.itcen.DTO.WorkerDTO;

public class WorkerDAO {
	
	DataSource dataSource;

	public static final int MEMBER_NONEXISTENT = 0;
	public static final int MEMBER_EXISTENT = 1;
	public static final int MEMBER_JOIN_FAIL = 0;
	public static final int MEMBER_JOIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_PW_NO_GOOD = 0;
	public static final int MEMBER_LOGIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_IS_NOT = -1;

	private static WorkerDAO instance = new WorkerDAO(); // 인스턴스를 자신이 자기를 생성해서 가리키고 있음
	
	public WorkerDAO() {

			try {
				Context context = new InitialContext();
				dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	public static WorkerDAO getInstance() {
		return instance;
	}
	// instance라는 변수는 heap 메모리에 생성된 memberdao의 주소를 가리키고 있고 이제 다른 servlet이나 jsp에서 따로
	// new memberdao로 새로운 memberdao를 생성하는 게 아니라 getinstance로 생성되어있는 instance를 불러내면서 여러 개의 memberdao 객체를 생성하지 않는다.

	public int insertWorker (WorkerDTO dto) {
		int ri = 0;
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		
		
		try {
			connection = dataSource.getConnection();
			String query = "insert into worker (WID, WPW, WNAME, WBIRTHDATE, WADDRESS, WPHONE_NUMBER, WEMAIL,  WSEX, WCERTIFICATE_NUMBER, WJOB, WCLINICAL_EXPERIENCE, WMAJOR_CAREER_YEARS, WMAJOR_CAREER_INSTITUTION, WSTATUS_OF_EMPLOYMENT, WCOVID_19_CLINICAL_EXPERIENCE, WSTATUS_OF_APPLY, WDATE) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'Y',?)";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, dto.getwId());
			pstmt.setString(2,  dto.getwPw());
			pstmt.setString(3,  dto.getwName());
			pstmt.setDate(4, dto.getwBirthdate());
			pstmt.setString(5, dto.getwAddress());
			pstmt.setString(6,  dto.getwPhone_number());
			pstmt.setString(7,  dto.getwEmail());
			pstmt.setString(8,  dto.getwSex());
			pstmt.setString(9,  dto.getwCertificate_number());
			pstmt.setString(10,  dto.getwJob());
			pstmt.setInt(11,  dto.getwClinical_experience());
			pstmt.setInt(12,  dto.getwMajor_career_years());
			pstmt.setString(13,  dto.getwMajor_career_institution());
			pstmt.setString(14,  dto.getwStatus_of_employment());
			pstmt.setString(15,  dto.getwCovid_19_clinical_experience());
			
			pstmt.setTimestamp(16,  dto.getwDate());
			
			pstmt.executeUpdate();
			ri = WorkerDAO.MEMBER_JOIN_SUCCESS;
		
		} catch (Exception e) {
			e.printStackTrace();
			//printStackTrace() = 에러 메세지의 발생 근원지를 찾아서 단계별로 에러를 출력한다
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return ri;
		
	}
	
	public int confirmId(String wId) {
		int ri = 0;
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		
		
		try {
			connection = dataSource.getConnection();
			String query = "select wId from worker where wId = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, wId);
			set = pstmt.executeQuery();
			if(set.next()) {
				ri = WorkerDAO.MEMBER_EXISTENT;
			} else {
				ri = WorkerDAO.MEMBER_NONEXISTENT;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				set.close();
				pstmt.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} return ri;
	}
	
	
	public int userCheck (String wId, String wPw) {
		int ri = 0;
		String dbPw;
		
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		

		try {
			connection = dataSource.getConnection();
			String query = "select wPw from worker where wId = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, wId);
			set = pstmt.executeQuery();
			if(set.next()) {
				dbPw = set.getString("wPw");
				if(dbPw.equals(wPw)) {
					ri = WorkerDAO.MEMBER_LOGIN_SUCCESS;
					}
				 else {
					ri = WorkerDAO.MEMBER_LOGIN_PW_NO_GOOD;
				}
			} else {
				ri = WorkerDAO.MEMBER_LOGIN_IS_NOT;
			}

	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			set.close();
			pstmt.close();
			connection.close();
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}
		return ri;
	}
	
	
	
	public WorkerDTO getMember (String wId) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		WorkerDTO dto = null;
		try {
			connection = dataSource.getConnection();
			String query = "select * from worker where wId = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, wId);
			set = pstmt.executeQuery();
			
			if(set.next()) {
				dto = new WorkerDTO();
				dto.setwId(set.getString("wId"));
				dto.setwPw(set.getString("wPw"));
				dto.setwName(set.getString("wName"));
				dto.setwBirthdate(set.getDate("wBirthdate"));
				dto.setwPhone_number(set.getString("wPhone_numer"));
				dto.setwSex(set.getString("wSex"));
				dto.setwCertificate_number(set.getString("wCertificate_number"));
				dto.setwJob(set.getString("wJob"));
				dto.setwClinical_experience(set.getInt("wClinical_experience"));
				dto.setwMajor_career_years(set.getInt("wMajor_career_years"));
				dto.setwMajor_career_institution(set.getString("wMajor_career_institution"));
				dto.setwStatus_of_employment(set.getString("wStatus_of_employment"));
				dto.setwCovid_19_clinical_experience(set.getString("wCovid_19_clinical_experience"));
				dto.setwStatus_of_apply(set.getString("wStatus_of_apply"));
				dto.setwEmail(set.getString("wEmail"));
				dto.setwDate(set.getTimestamp("wDate"));
				dto.setwAddress(set.getString("waddress"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				set.close();
				pstmt.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return dto;
	}
	public int updateMember(WorkerDTO dto) {
		int ri = 0;
		
		Connection connection = null;
		PreparedStatement pstmt = null;
				
		try {
			connection = dataSource.getConnection();
			String query = "update worker set wPw=?, wPhone_number=?, wCertificate_number=?, wJob=?, wClinical_experience=? wMajor_career_years=? wMajor_career_institution=?, wStatus_of_employment=? wCovid_19_clinical_experience=?, wEmail=?, wAddress=? where wId=?";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1,  dto.getwPw());
			pstmt.setString(2,  dto.getwPhone_number());
			pstmt.setString(3,  dto.getwCertificate_number());
			pstmt.setString(4,  dto.getwJob());
			pstmt.setInt(5,  dto.getwClinical_experience());
			pstmt.setInt(6,  dto.getwMajor_career_years());
			pstmt.setString(7,  dto.getwMajor_career_institution());
			pstmt.setString(8,  dto.getwStatus_of_employment());
			pstmt.setString(9,  dto.getwCovid_19_clinical_experience());
			pstmt.setString(10,  dto.getwEmail());
			pstmt.setString(11, dto.getwAddress());
			pstmt.setString(12, dto.getwId());
			ri = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	

}
