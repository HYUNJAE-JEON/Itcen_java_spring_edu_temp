package com.itcen.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.exercise.dto.BDto;
import com.itcen.DTO.RecruitmentDTO;

public class RecruitmentDAO {

	
	DataSource dataSource;
	
	public RecruitmentDAO() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void write(String bName, String bTitle, String bContent) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "insert into mvc_board (rId, bName, title, bContent, hit, bGroup, bStep, bIndent) values (mvc_board_seq.nextval, ?, ?, ?, 0, mvc_board_seq.currval, 0, 0)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  bName);
			preparedStatement.setString(2,  bTitle);
			preparedStatement.setString(3,  bContent);
			int rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	//임시 메소드
	public ArrayList<RecruitmentDTO> templist() {
		
		ArrayList<RecruitmentDTO> dtos = new ArrayList<RecruitmentDTO>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			connection = dataSource.getConnection();
			
			String query = "select * from Recruitment order by rId desc";
			// bGroup descend 되어있기 때문에 게시글이 사용될 때마다 최근에 입력한 
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				int rId = resultSet.getInt("rId");
				String rTitle = resultSet.getString("rTitle");
				Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
				int rHit = resultSet.getInt("rHit");
				String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
				String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
				String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
				String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
				int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
				String rManager_department = resultSet.getString("rManager_department");
				String rManager_call = resultSet.getString("rManager_call");
				String rContents = resultSet.getString("rContents");
				
				RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
				dtos.add(recruitmentDto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(resultSet != null) resultSet.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	
	
	// 페이징 + 필터
	
	public ArrayList<RecruitmentDTO> list(int startRow, int endRow, String rRecruitment_location_city_opt, String rRecruitment_location_district_opt, String rRecruitment_necessary_job_opt) {
		
		ArrayList<RecruitmentDTO> dtos = new ArrayList<RecruitmentDTO>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		
		try {
			connection = dataSource.getConnection();
			// 지역과 직무 검색 조건을 다 설정하지 않았을 때
			if (rRecruitment_location_city_opt == "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt == "N" ) {
			
				//rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents 
				String query = "select * from (select rownum rn, rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents from (select * from Recruitment order by rId desc)) where rn between ? and ?";
				// bGroup desc 되어있기 때문에 게시글이 사용될 때마다 최근에 입력한 
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, startRow);
				preparedStatement.setInt(2, endRow);
				resultSet = preparedStatement.executeQuery();
				
				while (resultSet.next()) {
					int rId = resultSet.getInt("rId");
					String rTitle = resultSet.getString("rTitle");
					Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
					int rHit = resultSet.getInt("rHit");
					String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
					String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
					String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
					String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
					int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
					String rManager_department = resultSet.getString("rManager_department");
					String rManager_call = resultSet.getString("rManager_call");
					String rContents = resultSet.getString("rContents");
					
					RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
					dtos.add(recruitmentDto);
				
				}	
			
			}
			// 지역(광역시, 도)는 선택하고 구,군,시는 선택하지 않았으며, 직무도 선택하지 않았을 때
			else if(rRecruitment_location_city_opt != "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt == "N") {
				String query = "select * from (select rownum rn, rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents from (select * from Recruitment where rRecruitment_location_city = " + rRecruitment_location_city_opt+ " order by rId desc)) where rn between ? and ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, startRow);
				preparedStatement.setInt(2, endRow);
				resultSet = preparedStatement.executeQuery();
				
				while (resultSet.next()) {
					int rId = resultSet.getInt("rId");
					String rTitle = resultSet.getString("rTitle");
					Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
					int rHit = resultSet.getInt("rHit");
					String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
					String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
					String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
					String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
					int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
					String rManager_department = resultSet.getString("rManager_department");
					String rManager_call = resultSet.getString("rManager_call");
					String rContents = resultSet.getString("rContents");
					
					RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
					dtos.add(recruitmentDto);
				}
			} 
			// 지역(광역시,도,구,군,시)만 설정하였을 때
			else if(rRecruitment_location_city_opt != "N" && rRecruitment_location_district_opt != "N" && rRecruitment_necessary_job_opt == "N") {
				String query = "select * from (select rownum rn, rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents from (select * from Recruitment where rRecruitment_location_city =" + rRecruitment_location_city_opt + "AND rRecruitment_location_district =" + rRecruitment_location_district_opt + "order by rId desc)) where rn between ? and ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, startRow);
				preparedStatement.setInt(2, endRow);
				resultSet = preparedStatement.executeQuery();
			
				while (resultSet.next()) {
					int rId = resultSet.getInt("rId");
					String rTitle = resultSet.getString("rTitle");
					Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
					int rHit = resultSet.getInt("rHit");
					String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
					String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
					String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
					String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
					int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
					String rManager_department = resultSet.getString("rManager_department");
					String rManager_call = resultSet.getString("rManager_call");
					String rContents = resultSet.getString("rContents");
					
					RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
					dtos.add(recruitmentDto);
				}
			} 
			// 지역(광역시,도)까지만 설정하고 직무를 선택하였을 때
			else if(rRecruitment_location_city_opt != "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt != "N"){
				String query = "select * from (select rownum rn, rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents from (select * from Recruitment where rRecruitment_location_city =" + rRecruitment_location_city_opt + "AND rRecruitment_necessary_job =" + rRecruitment_necessary_job_opt + "order by rId desc)) where rn between ? and ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, startRow);
				preparedStatement.setInt(2, endRow);
				resultSet = preparedStatement.executeQuery();
				
				while (resultSet.next()) {
					int rId = resultSet.getInt("rId");
					String rTitle = resultSet.getString("rTitle");
					Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
					int rHit = resultSet.getInt("rHit");
					String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
					String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
					String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
					String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
					int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
					String rManager_department = resultSet.getString("rManager_department");
					String rManager_call = resultSet.getString("rManager_call");
					String rContents = resultSet.getString("rContents");
					
					RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
					dtos.add(recruitmentDto);
				}
			}
			// 직무만 선택하였을 때
			else if(rRecruitment_location_city_opt == "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt != "N"){
				String query = "select * from (select rownum rn, rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents from (select * from Recruitment where rRecruitment_necessary_job =" + rRecruitment_necessary_job_opt + "order by rId desc)) where rn between ? and ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, startRow);
				preparedStatement.setInt(2, endRow);
				resultSet = preparedStatement.executeQuery();
				
				while (resultSet.next()) {
					int rId = resultSet.getInt("rId");
					String rTitle = resultSet.getString("rTitle");
					Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
					int rHit = resultSet.getInt("rHit");
					String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
					String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
					String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
					String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
					int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
					String rManager_department = resultSet.getString("rManager_department");
					String rManager_call = resultSet.getString("rManager_call");
					String rContents = resultSet.getString("rContents");
					
					RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
					dtos.add(recruitmentDto);
				}
			}
			// 전부 다 선택하였을 때
			else {
				String query = "select * from (select rownum rn, rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents from (select * from Recruitment where rRecruitment_location_city =" + rRecruitment_location_city_opt + "AND rRecruitment_location_district =" + rRecruitment_location_district_opt + " AND rRecruitment_necessary_job =" +  rRecruitment_necessary_job_opt + "order by rId desc)) where rn between ? and ?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setInt(1, startRow);
				preparedStatement.setInt(2, endRow);
				resultSet = preparedStatement.executeQuery();
				
				while (resultSet.next()) {
					int rId = resultSet.getInt("rId");
					String rTitle = resultSet.getString("rTitle");
					Timestamp rUpload_date = resultSet.getTimestamp("rUpload_date");
					int rHit = resultSet.getInt("rHit");
					String rStatus_of_recruitment = resultSet.getString("rStatus_of_recruitment");
					String rRecruitment_location_city = resultSet.getString("rRecruitment_location_city");
					String rRecruitment_location_district = resultSet.getString("rRecruitment_location_district");
					String rRecruitment_necessary_job = resultSet.getString("rRecruitment_necessary_job");
					int rRecruitment_num_of_worker = resultSet.getInt("rRecruitment_num_of_worker");
					String rManager_department = resultSet.getString("rManager_department");
					String rManager_call = resultSet.getString("rManager_call");
					String rContents = resultSet.getString("rContents");
					
					RecruitmentDTO recruitmentDto = new RecruitmentDTO(rId, rTitle, rUpload_date, rHit, rStatus_of_recruitment, rRecruitment_location_city, rRecruitment_location_district, rRecruitment_necessary_job, rRecruitment_num_of_worker, rManager_department, rManager_call, rContents);
					dtos.add(recruitmentDto);
				}
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(resultSet != null) resultSet.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	// 총 레코드 수 구하는 로직
	public int getCount() {
		int count = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "select count(*) from Recruitment";
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				count = resultSet.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(resultSet != null) resultSet.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} return count;
	}
	
	
	// 검색 후 페이지에 나타낼 총 레코드 수 계싼
	
	public int getfCount(String rRecruitment_location_city_opt, String rRecruitment_location_district_opt, String rRecruitment_necessary_job_opt) {
		int fCount = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			connection = dataSource.getConnection();
			// 지역과 직무 검색 조건을 다 설정하지 않았을 때
			if (rRecruitment_location_city_opt == "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt == "N" ) {
				String query = "select count(*) from Recruitment";
				preparedStatement = connection.prepareStatement(query);
				resultSet = preparedStatement.executeQuery();
				
				if(resultSet.next()) {
					fCount = resultSet.getInt(1);
				}
			} 
			// 지역(광역시, 도)는 선택하고 구,군,시는 선택하지 않았으며, 직무도 선택하지 않았을 
			else if(rRecruitment_location_city_opt != "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt == "N") {
				String query = "select count(*) from Recruitment where rRcruitment_location_city =" + rRecruitment_location_city_opt;
				preparedStatement = connection.prepareStatement(query);
				resultSet = preparedStatement.executeQuery();
				
				if(resultSet.next()) {
					fCount = resultSet.getInt(1);
				}
			} 
			// 지역(광역시,도,구,군,시)만 설정하였을 때
			else if(rRecruitment_location_city_opt != "N" && rRecruitment_location_district_opt != "N" && rRecruitment_necessary_job_opt == "N") {
				String query = "select count(*) from Recruitment where rRcruitment_location_city =" + rRecruitment_location_city_opt + "AND rRecruitment_location_district =" +rRecruitment_location_district_opt;
				preparedStatement = connection.prepareStatement(query);
				resultSet = preparedStatement.executeQuery();
				
				if(resultSet.next()) {
					fCount = resultSet.getInt(1);
				}
			} 
			// 지역(광역시,도)까지만 설정하고 직무를 선택하였을 때
			else if(rRecruitment_location_city_opt != "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt != "N") {
				String query = "select count(*) from Recruitment where rRcruitment_location_city =" + rRecruitment_location_city_opt + "AND rRecruitment_necessary_job =" + rRecruitment_necessary_job_opt;
				preparedStatement = connection.prepareStatement(query);
				resultSet = preparedStatement.executeQuery();
				
				if(resultSet.next()) {
					fCount = resultSet.getInt(1);
				}
			}
			// 직무만 선택하였을 때
			else if(rRecruitment_location_city_opt == "N" && rRecruitment_location_district_opt == "N" && rRecruitment_necessary_job_opt != "N") {
				String query = "select count(*) from Recruitment where rRecruitment_necessary_job =" + rRecruitment_necessary_job_opt;
				preparedStatement = connection.prepareStatement(query);
				resultSet = preparedStatement.executeQuery();
				
				if(resultSet.next()) {
					fCount = resultSet.getInt(1);
				}
			}
			//전부 선택하였을 때
			else {
				String query = "select * from Recruitment where rRecruitment_location_city =" + rRecruitment_location_city_opt + "AND rRecruitment_location_district =" + rRecruitment_location_district_opt + " AND rRecruitment_necessary_job =" +  rRecruitment_necessary_job_opt;
				preparedStatement = connection.prepareStatement(query);
				resultSet = preparedStatement.executeQuery();
				
				if(resultSet.next()) {
					fCount = resultSet.getInt(1);
				}
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(resultSet != null) resultSet.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} return fCount;

	}
	
	
	
	public RecruitmentDTO contentView(String strID) {
		upHit(strID);
		
		RecruitmentDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			connection = dataSource.getConnection();
			
			String query = "select * from mvc_board where rId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,  Integer.parseInt(strID));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				int bId = resultSet.getInt("rId");
				String bName = resultSet.getString("bName");
				String bTitle = resultSet.getString("title");
				String bContent = resultSet.getString("bContent");
				Timestamp bDate = resultSet.getTimestamp("upload_date");
				int bHit = resultSet.getInt("hit");
				int bGroup = resultSet.getInt("bGroup");
				int bStep = resultSet.getInt("bStep");
				int bIndent = resultSet.getInt("bIndent");
				
				dto = new RecruitmentDTO(bId, bName, bTitle, bContent, bDate, bHit, bGroup, bStep, bIndent);
	
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(resultSet != null) resultSet.close();
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	public void modify(String bId, String bName, String bTitle, String bContent) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			
			String query = "update mvc_board set bName = ?, title = ?, bContent = ? where rId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  bName);
			preparedStatement.setString(2,  bTitle);
			preparedStatement.setString(3,  bContent);
			preparedStatement.setInt(4,  Integer.parseInt(bId));
			int rn = preparedStatement.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
	
	public void delete(String bId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			
			connection = dataSource.getConnection();
			String query = "delete from mvc_board where rId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,  Integer.parseInt(bId));
			int rn = preparedStatement.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public RecruitmentDTO reply_view(String str) {
		
		RecruitmentDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			
			connection = dataSource.getConnection();
			String query = "select * from mvc_board where bid = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,  Integer.parseInt(str));
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				int bId = resultSet.getInt("rId");
				String bName = resultSet.getString("bName");
				String bTitle = resultSet.getString("title");
				String bContent = resultSet.getString("bContent");
				Timestamp bDate = resultSet.getTimestamp("upload_date");
				int bHit = resultSet.getInt("hit");
				int bGroup = resultSet.getInt("bGroup");
				int bStep = resultSet.getInt("bStep");
				int bIndent = resultSet.getInt("bIndent");
				
				dto = new RecruitmentDTO(bId, bName, bTitle, bContent, bDate, bHit, bGroup, bStep, bIndent);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	} 
	
	public void reply(String bId, String bName, String bTitle, String bContent, String bGroup, String bStep, String bIndent) {
		replyShape(bGroup, bStep);
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "insert into mvc_board (rId, bName, title, bContent, bGroup, bStep, bIndent) values (mvc_board_seq.nextval, ?, ?, ?, ? ,? ,?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  bName);
			preparedStatement.setString(2,  bTitle);
			preparedStatement.setString(3,  bContent);
			preparedStatement.setInt(4,  Integer.parseInt(bGroup));
			preparedStatement.setInt(5,  Integer.parseInt(bStep) + 1);
			preparedStatement.setInt(6,  Integer.parseInt(bIndent) + 1);
		
			int rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	private void replyShape(String strGroup, String strStep) {
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "update mvc_board set bStep = bStep + 1 where bGroup = ? and bStep > ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1,  Integer.parseInt(strGroup));
			preparedStatement.setInt(2, Integer.parseInt(strStep));

			int rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	private void upHit (String bId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "update mvc_board set hit = hit + 1 where rId = ?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, bId);
			
			int rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
}


	