package com.itcen.Frontcontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itcen.RecruitmentCommand.BCommand;
import com.itcen.RecruitmentCommand.MRecruitment_deleteCommand;
import com.itcen.RecruitmentCommand.MRecruitment_modifyCommand;
import com.itcen.RecruitmentCommand.MRecruitment_writeCommand;
import com.itcen.RecruitmentCommand.Putoff_reply;
import com.itcen.RecruitmentCommand.Putoff_replyview;
import com.itcen.RecruitmentCommand.WRecruitment_contentCommand;
import com.itcen.RecruitmentCommand.WRecruitment_viewCommand;
import com.itcen.WorkerCommand.WJoin_Command;
import com.itcen.WorkerCommand.WLogin_Command;
import com.itcen.WorkerCommand.WModify_Command;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("doGet");
		actionDo(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		System.out.println("doPost");
		actionDo(request, response);
	}

	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo");
		
		request.setCharacterEncoding("EUC-KR");
	
		String viewPage = null;
		BCommand command = null;
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		if(com.equals("/write_view.do")) {
			viewPage = "write_view.jsp";
		} else if (com.equals("/write.do")) {
			command = new MRecruitment_writeCommand();
			command.execute(request, response);
			viewPage = "list.do";
		} else if (com.equals("/Recruitment.do")) {
			command = new WRecruitment_viewCommand();
			command.execute(request, response);
			viewPage = "Recruitment.jsp";
		}else if (com.equals("/content_view.do")) {
			command = new WRecruitment_contentCommand();
			command.execute(request, response);
			viewPage = "content_view.jsp";
		}else if (com.equals("/modify.do")) {
			command = new MRecruitment_modifyCommand();
			command.execute(request, response);
			viewPage = "list.do";
		}else if (com.equals("/delete.do")) {
			command = new MRecruitment_deleteCommand();
			command.execute(request, response);
			viewPage = "list.do";
		}else if (com.equals("/reply_view.do")) {
			command = new Putoff_replyview();
			command.execute(request, response);
			viewPage = "reply_view.jsp";
		}else if (com.equals("/reply.do")) {
			command = new Putoff_reply();
			command.execute(request, response);
			viewPage = "list.do";
		}else if (com.equals("/login.do")) {
			command = new WLogin_Command();
			command.execute(request, response);
			viewPage = "Recruitment.do";
		}else if (com.equals("/join.do")) {
			command = new WJoin_Command();
			command.execute(request, response);
		}else if (com.equals("/modifymember.do")) {
			command = new WModify_Command();
			command.execute(request, response);
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage); //forward 할 페이지를 매개변수로 넣는다. 
		dispatcher.forward(request, response);
	}
}
