package com.itcen.WorkerCommand;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itcen.DAO.WorkerDAO;
import com.itcen.DTO.WorkerDTO;
import com.itcen.RecruitmentCommand.BCommand;

public class WModify_Command implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("EUC-KR");
		response.setContentType("text/html; charset=euc-kr");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		WorkerDTO workerDto = new WorkerDTO();
		
		String wId = (String)session.getAttribute("wId");
		String wName = (String)session.getAttribute("wName");
		workerDto.setwId(wId);
		workerDto.setwName(wName);
		
		String wPw = request.getParameter("wPw");
		String wPhone_number = request.getParameter("wPhone_number");
		int wCertificate_number = Integer.parseInt(request.getParameter("wCertificate_number"));
		String wJob = request.getParameter("wJob");
		int wClinical_experience = Integer.parseInt(request.getParameter("wClinical_experience"));
		int wMajor_career_years = Integer.parseInt(request.getParameter("wMjaor_career_years"));
		String wMajor_career_institution = request.getParameter("wMajor_career_institution");
		String wStatus_of_employment = request.getParameter("wStatus_of_employment");
		String wCovid_19_clinical_experience = request.getParameter("wCovid_19_clinical_experience");
		String wEmail = request.getParameter("wEmail");
		String wAddress = request.getParameter("wAddress");
		workerDto.setwPw(wPw);
		workerDto.setwPhone_number(wPhone_number);
		workerDto.setwCertificate_number(wCertificate_number);
		workerDto.setwJob(wJob);
		workerDto.setwClinical_experience(wClinical_experience);
		workerDto.setwMajor_career_years(wMajor_career_years);
		workerDto.setwMajor_career_institution(wMajor_career_institution);
		workerDto.setwStatus_of_employment(wStatus_of_employment);
		workerDto.setwCovid_19_clinical_experience(wCovid_19_clinical_experience);
		workerDto.setwEmail(wEmail);
		workerDto.setwAddress(wAddress);
		
		WorkerDAO workerDao = WorkerDAO.getInstance();
		int ri = workerDao.updateMember(workerDto);
		if (ri == 1) {
			writer.println("<script language='javascript'>");
			writer.println("alert('정보수정 되었습니다.');");
			writer.println("document.location.href='Recruitment.jsp'");
			writer.println("</script>");
			writer.close();
			
		} else {
			writer.println("<script language='javascript'>");
			writer.println("alert('정보수정 실패입니다.');");
			writer.println("history.go(-1)");
			writer.println("</script>");
			writer.close();
		}
	}
}
