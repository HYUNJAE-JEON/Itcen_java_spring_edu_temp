package com.itcen.WorkerCommand;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itcen.DAO.WorkerDAO;
import com.itcen.DTO.WorkerDTO;
import com.itcen.RecruitmentCommand.BCommand;

public class WLogin_Command implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		String checklogin = request.getParameter("memberlogin");
		response.setContentType("text/html; charset=euc-kr");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();

		if (checklogin.equals("worker")) {
			
			String wId = request.getParameter("wId");
			String wPw = request.getParameter("wPw");
			WorkerDAO workerDao = WorkerDAO.getInstance();
			int checkNum = workerDao.userCheck(wId, wPw);

			if(checkNum == -1) {
			
			writer.println("<script>");
			writer.println("alert('아이디가 존재하지 않습니다.');");
			writer.println("history.go(-1);");
			writer.println("</script>");
			writer.close();
			} else if(checkNum == 0) {
			writer.println("<script>");
			writer.println("alert('비밀번호가 틀립니다.');");
			writer.println("history.go(-1);");
			writer.println("</script>");
			writer.close();
			} else if(checkNum == 1) {
				WorkerDTO workerDto = workerDao.getMember(wId);
				
				if(workerDto == null) {
					writer.println("<script>");
					writer.println("alert('존재하지 않는 회원 입니다.');");
					writer.println("history.go(-1);");
					writer.println("</script>");
					writer.close();	
				} else {
					String wName = workerDto.getwName();

					session.setAttribute("id", wId);
					session.setAttribute("name", wName);
					session.setAttribute("ValidMem", "yes");
	//				response.sendRedirect("list.jsp");
				}
			}
		} else if(checklogin.equals("institution")) {
			writer.println("<script>");
			writer.println("alert('개발 중인 기능입니다. 문의:ysysyshy@naver.com');");
			writer.println("history.go(-1);");
			writer.println("</script>");
			writer.close();
		} else if(checklogin.equals("manager")) {
			String mId = request.getParameter("wId");
			String mPw = request.getParameter("wPw");
			
			if(mId.equals("manager") && mPw.equals("1234")) {
				writer.println("<script>");
				writer.println("alert('관리자 모드입니다.');");
				writer.println("document.location.href='Main.jsp'");
				writer.println("</script>");
				writer.close();
			} else {
				writer.println("<script>");
				writer.println("alert('권한이 없는 아이디입니다. 권한 문의:ysysyshy@naver.com');");
				writer.println("history.go(-1);");
				writer.println("</script>");
				writer.close();
			}
		}
		

		
			
		}
	}


